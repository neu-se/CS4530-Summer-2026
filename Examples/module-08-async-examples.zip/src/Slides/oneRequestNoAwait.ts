import { fakeRequest } from '../utils/fakeRequest.ts';
import  timeIt  from '../utils/timeIt.ts';

async function main() {
  console.log('main started');
  const request = 32;
  const res = fakeRequest(request);
  console.log(`fakeRequest(${request}) returned: ${res}`);
  console.log('main done');
}

timeIt(main);

/** fakeRequest just creates a promise and returns it.
 * 1. We are not awaiting the promise returned by fakeRequest.
 * 2. The promise not resolved until the current promise (main) is resolved.
 */
