import axios from 'axios';//

export async function makeRequest(requestNumber: number) {
  console.log(`starting makeRequest(${requestNumber})`);
  // this example needs axion; doesn't work with fetch alone
  const response = await axios.get('https://rest-example.covey.town');
  //  await fetch('https://rest-example.covey.town');
  console.log('request:', requestNumber, '\nresponse:', response.data);
}

async function main() {
  console.log('starting main');
  makeRequest(100);
  console.log('main finished');
}

main();
