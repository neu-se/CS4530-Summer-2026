// consider the following program
import axios from 'axios'

// generate a random http request
async function someComputation(n: number) {
    console.log("A"+n); 
    const randomNumber = Math.random() * 10000
    const res = await axios.get(`https://httpbin.org/get?answer=${randomNumber}`)
    console.log("Z"+n); 
}

async function f() { await someComputation(1); await Promise.all([g(), h(), i()]) }

async function g() { await someComputation(2); console.log("G") }

async function h() { console.log("H1"); 
                     console.log("H2") }

async function i() { await someComputation(3); console.log("I") }
                     
console.log("M1");
await f();
console.log("M2");