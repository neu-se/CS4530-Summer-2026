import { waitRandom } from '../utils/fakeRequest.ts';

async function asyncPrintA() {
    await waitRandom(1);  
    console.log('A');
}

async function asyncPrintBC() {
    await waitRandom(2);    
    console.log('B');
    console.log('C');
}

async function run() {
    await Promise.all([asyncPrintA(), asyncPrintBC()])
}
