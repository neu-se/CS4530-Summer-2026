import { fakeRequest, makeRequest } from '../utils/fakeRequest.ts';
import timeIt from '../utils/timeIt.ts';

async function main() {
  console.log('main started');
  console.log('sync task');
  Promise.resolve().then( () => {
    console.log('promise');
  } );
  setTimeout(() => {
    console.log('timeout');
  }, 0);
  //fakeRequest(20);
   //makeRequest(10);
   //makeRequest(20);
   //makeRequest(30);

   console.log('main done');
}

main()