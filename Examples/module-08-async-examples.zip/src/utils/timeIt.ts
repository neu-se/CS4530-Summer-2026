export default async function timeIt(thunk: () => any): Promise<number> {
  const t0 = performance.now();
  await thunk();
  const t1 = performance.now();
  console.log((t1 - t0).toFixed(2), 'msec');
  return t1 - t0;
}
