import { type IClock } from '../Interfaces/IClock.ts';

/** Clock With Listeners (delegates)
 * This is a singleton class that creates a clock that ticks at a regular interval.
 * It does *NOT* keep track of the time.
 * It has a list of listeners that it notifies on each tick.
 */

// the listener does not expect an argument
type Listener = () => void;

class Clock implements IClock {
  private _listeners: Listener[] = [];

  // notify all listeners, if the clock is running
  private _notifyAll() {
    this._listeners.forEach(eachListener => {
      eachListener();
    });
  }

  public addListener(listener: Listener) {
    this._listeners.push(listener);
  }
  public removeListener(listener: Listener) {
    this._listeners = this._listeners.filter(eachListener => eachListener !== listener);
  }

  get nListeners() {
    return this._listeners.length;
  }

  // the actual clock state.
  // it runs all the time, but only notifies listeners when
  // this._running is true
  // initially, the clock is stopped
  private _running: boolean = false;
  private _interval: number = 1000; // default 1 second

  private _createTimer() {
    setInterval(() => {
      if (this._running) {
        this._notifyAll();
      }
    }, this._interval);
  }

  public constructor(interval: number) {
    this._interval = interval;
    this._createTimer();
    this.start();
  }

  // this idiom guarantees that 'this' is bound statically.
  // the timer doesn't start until you call start(),
  public start = () => {
    this._running = true;
  };

  public stop = () => {
    this._running = false;
  };
}

export default class SingletonClockFactory {
  private static _instance: Clock | null = null;
  public static getInstance(interval: number) {
    if (SingletonClockFactory._instance === null) {
      SingletonClockFactory._instance = new Clock(interval);
    }
    return SingletonClockFactory._instance;
  }
}
