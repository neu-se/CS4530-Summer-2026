import { extendTheme } from '@chakra-ui/react';

const theme = extendTheme({
  components: {
    Box: {
      baseStyle: {
        border: '1px solid black',
        padding: '1px',
      },
    },
    // Button comes with many variants;
    // and we need to override the default variant (which is 'solid')
    Button: {
      baseStyle: {
        border: '2px solid green',
        color: 'red',
      },
      variants: {
        solid: {
          bg: 'transparent',
          color: 'red',
          border: '2px solid green',
          _hover: {
            bg: 'gray.100',
          },
        },
      },
      defaultProps: {
        variant: 'solid',
      },
    },
    Input: {
      variants: {
        outline: {
          field: {
            borderColor: 'black',
            _focus: {
              borderColor: 'green',
              boxShadow: '0 0 0 1px green',
            },
          },
        },
      },
    },
  },
});

export default theme;
