// import App from './Components/HelloWorld.tsx';
// import App from './Components/HelloWorldAveryAndDave.tsx';
// import App from './Components/TwoCountingButtons.tsx'
// import App from './Components/CountingButton.tsx'
// import App from './Apps/ToDoApp/ToDoApp.tsx';
// import App from './Components/SimplestState.tsx'
// import App from './Apps/ThreeClocks/App.tsx'
import App from './Apps/ThreeClocksWithUseClock/App.tsx';
// import App from './useEffect-demo.tsx'
// import App from './UseEffectDemos/useEffect-demoWithCleanUps.tsx'
// import App from './Apps/ArrayOfClocks/App.tsx'

export default App;
