import { useState, useEffect } from 'react';
import { Heading, Table, Tbody, Tr, Td, VStack } from '@chakra-ui/react';
import SingletonClockFactory from '../../Classes/SingletonClockFactory.ts';
import { type IClock } from '../../Interfaces/IClock.ts';

//
type ClockDisplayData = { key: number; name: string; clock: IClock };

import ClockDisplay from '../../Components/ClockDisplay.tsx';

// static data for a display
function makeClockDisplayData(key: number, clock: IClock): ClockDisplayData {
  return { key: key, name: 'clock ' + key, clock: clock };
}

// assemble a ClockDisplay component from the static and dynamic data
function makeClockDisplay(
  data: ClockDisplayData,
  handleAdd: () => void,
  handleDelete: (key: number) => void,
) {
  return (
    <ClockDisplay
      name={data.name}
      key={data.key}
      handleDelete={() => handleDelete(data.key)}
      clock={data.clock}
      handleAdd={handleAdd}
    />
  );
}

function makeTableRow(element: JSX.Element, key: number) {
  return (
    <Tr key={key}>
      <Td>{element}</Td>
    </Tr>
  );
}

export default function App() {
  const clock = SingletonClockFactory.getInstance(1000);

  // static data for the clocks displays
  const [clockDisplayData, setClockDisplayData] = useState<ClockDisplayData[]>([]);

  // dynamic data for the next key
  const [nextKey, setNextKey] = useState(1);

  function handleAdd() {
    const newDisplay = makeClockDisplayData(nextKey, clock);
    setClockDisplayData(clockDisplayData.concat(newDisplay));
    setNextKey(nextKey + 1);
  }

  function handleDelete(targetKey: number) {
    const newList = clockDisplayData.filter(item => item.key !== targetKey);
    setClockDisplayData(newList);
  }

  // add a clock display for the first render
  // not sure how else to fix this :(

  useEffect(() => {
    handleAdd();
  }, []);

  return (
    <VStack>
      <Heading>Array of Clocks</Heading>
      <Table>
        <Tbody>
          {clockDisplayData.map(
            (cd: ClockDisplayData): JSX.Element =>
              makeTableRow(makeClockDisplay(cd, handleAdd, handleDelete), cd.key),
          )}
        </Tbody>
      </Table>
    </VStack>
  );
}
