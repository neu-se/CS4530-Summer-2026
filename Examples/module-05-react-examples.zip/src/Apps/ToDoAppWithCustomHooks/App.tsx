// illustrates the use of useToDoItemList

import { Heading, VStack } from '@chakra-ui/react';

// import { type ToDoItem } from './ToDoListTypes'
import { ToDoItemEntryForm } from './ToDoItemEntryForm.tsx';
import { ToDoListDisplay } from './ToDoListDisplay.tsx';
import useToDoItemList from './useToDoItemList.ts';

export default function ToDoApp() {
  const { todoList, handleAdd, handleDelete } = useToDoItemList();

  return (
    <VStack>
      <Heading>TODO List</Heading>
      <ToDoItemEntryForm onAdd={handleAdd} />
      <ToDoListDisplay items={todoList} onDelete={handleDelete} />
    </VStack>
  );
}
