// illustrates encapsulation of business logic in a custom hook

import { useState } from 'react';

import { type ToDoItem } from './ToDoListTypes.ts';

export default function useToDoItemList(): {
  todoList: ToDoItem[];
  handleAdd: (title: string, priority: string) => void;
  handleDelete: (key: number) => void;
} {
  const [todoList, setTodolist] = useState<ToDoItem[]>([]);
  const [itemKey, setItemKey] = useState<number>(0); // first unused key

  function handleAdd(title: string, priority: string) {
    if (title === '') {
      return;
    } // ignore blank button presses
    setTodolist(todoList.concat({ title: title, priority: priority, key: itemKey }));
    setItemKey(itemKey + 1);
  }

  function handleDelete(targetKey: number) {
    const newList = todoList.filter(item => item.key !== targetKey);
    setTodolist(newList);
  }

  return { todoList: todoList, handleAdd: handleAdd, handleDelete: handleDelete };
}

//   return (
//   <VStack>
//     <Heading>TODO List</Heading>
//     <ToDoItemEntryForm onAdd={handleAdd}/>
//     <ToDoListDisplay items={todoList} onDelete={handleDelete}/>
//   </VStack>
//   )
// }
