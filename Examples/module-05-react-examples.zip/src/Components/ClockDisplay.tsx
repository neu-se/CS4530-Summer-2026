import * as React from 'react';
import { useState, useEffect } from 'react';
import { Box, Button, HStack, IconButton } from '@chakra-ui/react';
import { AiOutlineDelete, AiOutlinePlus } from 'react-icons/ai';
import { type IClock } from '../Interfaces/IClock.ts';

export type ClockDisplayProps = {
  name: string;
  key: number;
  clock: IClock;
  handleDelete: () => void;
  handleAdd: () => void;
};

export default function ClockDisplay(props: ClockDisplayProps) {
  const [localTime, setLocalTime] = useState(0);
  const incrementLocalTime = () => {
    setLocalTime(localTime => localTime + 1);
  };

  const clock = props.clock;

  useEffect(() => {
    const listener1 = () => {
      incrementLocalTime();
    };
    props.clock.addListener(listener1);
    console.log(`ClockDisplay ${props.name} is mounting`);
    return () => {
      console.log('ClockDisplay ' + props.name + ' is unmounting');
      props.clock.removeListener(listener1);
    };
  }, [props.clock, props.name]);

  return (
    <HStack>
      <Box>Clock: {props.name}</Box>
      <Box>Time = {localTime}</Box>
      <Box>nlisteners = {clock.nListeners}</Box>
      <Button aria-label={'start'} onClick={() => clock.start()}>
        Start
      </Button>
      <Button aria-label={'stop'} onClick={() => clock.stop()}>
        Stop
      </Button>
      <IconButton aria-label={'delete'} onClick={props.handleDelete} icon={<AiOutlineDelete />} />
      <IconButton aria-label={'add'} onClick={props.handleAdd} icon={<AiOutlinePlus />} />
    </HStack>
  );
}

//
