// 'use client;'; // this file is client-side only
// simplest app, demonstrates useState, Button

import * as React from 'react';
import { useState } from 'react';
import { Box, Button, VStack } from '@chakra-ui/react';

// turn on console to demonstrate asynchrony
// In console, set levels to 'default'

// for style parameters, see https://chakra-ui.com/docs/styled-system/style-props

export default function SimplestState() {
  const [count, setCount] = useState(0);

  function handleClick() {
    setCount(count + 1);
  }

  return (
    <VStack>
      <Box border={'1px'} padding={1}>
        count = {count}
      </Box>
      <Button onClick={handleClick}>Increment Count!</Button>
    </VStack>
  );
}
